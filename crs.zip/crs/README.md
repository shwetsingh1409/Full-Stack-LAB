# Expense Tracker

A full-stack expense tracking application built with React + Vite (frontend) and Node.js (backend). This application allows users to create, read, update, and delete expense entries.

## Features

- Create new expense entries
- View all expenses in a list
- Update existing expenses
- Delete expenses
- Categorize expenses
- Track payment methods
- Responsive design with Tailwind CSS

## Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

## Project Structure

```
expense-tracker/
├── expense-tracker-frontend/    # React + Vite frontend
└── expense-tracker-backend/     # Node.js backend
```

## Setup and Running

### Backend

1. Navigate to the backend directory:
   ```bash
   cd expense-tracker-backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

The backend server will run on `http://localhost:5000`.

### Frontend

1. Navigate to the frontend directory:
   ```bash
   cd expense-tracker-frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

The frontend application will be available at `http://localhost:5173`.

## Technologies Used

### Frontend
- React
- TypeScript
- Vite
- Tailwind CSS
- Axios
- Heroicons

### Backend
- Node.js
- Express
- CORS
- UUID 