const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage for expenses
let expenses = [];

// Get all expenses
app.get('/api/expenses', (req, res) => {
  res.json(expenses);
});

// Create a new expense
app.post('/api/expenses', (req, res) => {
  const newExpense = {
    id: uuidv4(),
    ...req.body,
    date: new Date(req.body.date)
  };
  expenses.push(newExpense);
  res.status(201).json(newExpense);
});

// Update an expense
app.put('/api/expenses/:id', (req, res) => {
  const { id } = req.params;
  const index = expenses.findIndex(expense => expense.id === id);
  
  if (index === -1) {
    return res.status(404).json({ message: 'Expense not found' });
  }

  const updatedExpense = {
    ...expenses[index],
    ...req.body,
    id,
    date: new Date(req.body.date)
  };
  
  expenses[index] = updatedExpense;
  res.json(updatedExpense);
});

// Delete an expense
app.delete('/api/expenses/:id', (req, res) => {
  const { id } = req.params;
  const index = expenses.findIndex(expense => expense.id === id);
  
  if (index === -1) {
    return res.status(404).json({ message: 'Expense not found' });
  }

  expenses = expenses.filter(expense => expense.id !== id);
  res.status(204).send();
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
}); 