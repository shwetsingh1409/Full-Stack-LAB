import { useState, useEffect } from 'react';
import { api } from './services/api';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [editingExpense, setEditingExpense] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchExpenses();
  }, []);

  const fetchExpenses = async () => {
    try {
      setLoading(true);
      const data = await api.getExpenses();
      setExpenses(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch expenses');
      console.error('Error fetching expenses:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddExpense = async (formData) => {
    try {
      const newExpense = await api.createExpense(formData);
      setExpenses([...expenses, newExpense]);
      setError(null);
    } catch (err) {
      setError('Failed to add expense');
      console.error('Error adding expense:', err);
    }
  };

  const handleUpdateExpense = async (formData) => {
    if (!editingExpense) return;

    try {
      const updatedExpense = await api.updateExpense(editingExpense.id, formData);
      setExpenses(expenses.map(expense => 
        expense.id === updatedExpense.id ? updatedExpense : expense
      ));
      setEditingExpense(null);
      setError(null);
    } catch (err) {
      setError('Failed to update expense');
      console.error('Error updating expense:', err);
    }
  };

  const handleDeleteExpense = async (id) => {
    try {
      await api.deleteExpense(id);
      setExpenses(expenses.filter(expense => expense.id !== id));
      setError(null);
    } catch (err) {
      setError('Failed to delete expense');
      console.error('Error deleting expense:', err);
    }
  };

  const handleEditClick = (expense) => {
    setEditingExpense(expense);
  };

  return (
    <div className="min-h-screen bg-gray-100 py-6 flex flex-col justify-center sm:py-12">
      <div className="relative py-3 sm:max-w-xl sm:mx-auto">
        <div className="relative px-4 py-10 bg-white shadow-lg sm:rounded-3xl sm:p-20">
          <div className="max-w-md mx-auto">
            <div className="divide-y divide-gray-200">
              <div className="py-8 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7">
                <h1 className="text-3xl font-bold text-center mb-8">Expense Tracker</h1>
                
                {error && (
                  <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
                    {error}
                  </div>
                )}

                <ExpenseForm 
                  onSubmit={editingExpense ? handleUpdateExpense : handleAddExpense}
                  initialData={editingExpense}
                />

                {loading ? (
                  <div className="text-center text-gray-500 mt-4">Loading expenses...</div>
                ) : (
                  <ExpenseList 
                    expenses={expenses}
                    onDelete={handleDeleteExpense}
                    onEdit={handleEditClick}
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App; 