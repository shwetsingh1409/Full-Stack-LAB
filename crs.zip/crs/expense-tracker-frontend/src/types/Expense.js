// Expense object structure
export const createExpense = (data) => ({
  id: data.id || '',
  title: data.title || '',
  amount: data.amount || 0,
  category: data.category || '',
  date: data.date || new Date(),
  paymentMethod: data.paymentMethod || ''
}); 