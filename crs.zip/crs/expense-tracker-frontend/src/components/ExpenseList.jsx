import React from 'react';
import { PencilIcon, TrashIcon } from '@heroicons/react/24/outline';

const ExpenseList = ({ expenses, onDelete, onEdit }) => {
  if (expenses.length === 0) {
    return (
      <div className="text-center text-gray-500 mt-4">
        No expenses added yet. Add your first expense above!
      </div>
    );
  }

  return (
    <div className="mt-8">
      <h2 className="text-xl font-semibold mb-4">Expense List</h2>
      <div className="space-y-4">
        {expenses.map(expense => (
          <div
            key={expense.id}
            className="bg-white p-4 rounded-lg shadow hover:shadow-md transition-shadow"
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-medium">{expense.title}</h3>
                <p className="text-gray-600">${expense.amount.toFixed(2)}</p>
                <div className="mt-2 space-y-1">
                  <p className="text-sm text-gray-500">
                    Category: <span className="font-medium">{expense.category}</span>
                  </p>
                  <p className="text-sm text-gray-500">
                    Date: <span className="font-medium">
                      {new Date(expense.date).toLocaleDateString()}
                    </span>
                  </p>
                  <p className="text-sm text-gray-500">
                    Payment Method: <span className="font-medium">{expense.paymentMethod}</span>
                  </p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => onEdit(expense)}
                  className="p-2 text-blue-600 hover:text-blue-800"
                  title="Edit"
                >
                  <PencilIcon className="h-5 w-5" />
                </button>
                <button
                  onClick={() => onDelete(expense.id)}
                  className="p-2 text-red-600 hover:text-red-800"
                  title="Delete"
                >
                  <TrashIcon className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExpenseList; 