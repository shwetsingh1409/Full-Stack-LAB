import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

export const api = {
  // Get all expenses
  getExpenses: async () => {
    const response = await axios.get(`${API_URL}/expenses`);
    return response.data;
  },

  // Create a new expense
  createExpense: async (expense) => {
    const response = await axios.post(`${API_URL}/expenses`, expense);
    return response.data;
  },

  // Update an expense
  updateExpense: async (id, expense) => {
    const response = await axios.put(`${API_URL}/expenses/${id}`, expense);
    return response.data;
  },

  // Delete an expense
  deleteExpense: async (id) => {
    await axios.delete(`${API_URL}/expenses/${id}`);
  },
}; 